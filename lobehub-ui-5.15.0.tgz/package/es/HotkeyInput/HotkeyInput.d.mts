import { HotkeyInputProps } from "./type.mjs";
import * as _$react from "react";

//#region src/HotkeyInput/HotkeyInput.d.ts
declare const HotkeyInput: _$react.NamedExoticComponent<HotkeyInputProps>;
//#endregion
export { HotkeyInput };
//# sourceMappingURL=HotkeyInput.d.mts.map