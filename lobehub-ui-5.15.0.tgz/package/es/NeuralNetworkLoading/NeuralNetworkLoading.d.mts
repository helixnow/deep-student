import { NeuralNetworkLoadingProps } from "./type.mjs";
import * as _$react from "react";

//#region src/NeuralNetworkLoading/NeuralNetworkLoading.d.ts
declare const NeuralNetworkLoading: _$react.NamedExoticComponent<NeuralNetworkLoadingProps>;
//#endregion
export { NeuralNetworkLoading };
//# sourceMappingURL=NeuralNetworkLoading.d.mts.map