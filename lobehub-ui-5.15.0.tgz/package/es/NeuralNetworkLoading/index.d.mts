import { NeuralNetworkLoadingProps } from "./type.mjs";
import { NeuralNetworkLoading } from "./NeuralNetworkLoading.mjs";
export { NeuralNetworkLoadingProps, NeuralNetworkLoading as default };