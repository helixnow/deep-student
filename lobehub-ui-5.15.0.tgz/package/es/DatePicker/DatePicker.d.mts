import { DatePickerProps } from "./type.mjs";
import * as _$react from "react";

//#region src/DatePicker/DatePicker.d.ts
declare const DatePicker: _$react.NamedExoticComponent<DatePickerProps>;
//#endregion
export { DatePicker };
//# sourceMappingURL=DatePicker.d.mts.map