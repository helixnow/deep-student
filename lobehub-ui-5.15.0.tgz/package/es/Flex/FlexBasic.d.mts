import { FlexBasicProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Flex/FlexBasic.d.ts
declare const _default: _$react.NamedExoticComponent<FlexBasicProps>;
//#endregion
export { _default };
//# sourceMappingURL=FlexBasic.d.mts.map