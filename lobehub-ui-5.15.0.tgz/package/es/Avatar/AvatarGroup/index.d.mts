import { AvatarGroupProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Avatar/AvatarGroup/index.d.ts
declare const AvatarGroup: _$react.NamedExoticComponent<AvatarGroupProps>;
//#endregion
export { AvatarGroup };
//# sourceMappingURL=index.d.mts.map