import { MermaidProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Mermaid/Mermaid.d.ts
declare const Mermaid: _$react.NamedExoticComponent<MermaidProps>;
//#endregion
export { Mermaid };
//# sourceMappingURL=Mermaid.d.mts.map