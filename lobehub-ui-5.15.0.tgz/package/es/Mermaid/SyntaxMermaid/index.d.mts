import { SyntaxMermaidProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Mermaid/SyntaxMermaid/index.d.ts
declare const SyntaxMermaid: _$react.NamedExoticComponent<SyntaxMermaidProps>;
//#endregion
export { SyntaxMermaid };
//# sourceMappingURL=index.d.mts.map