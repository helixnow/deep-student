import { AccordionProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Accordion/Accordion.d.ts
declare const Accordion: _$react.NamedExoticComponent<AccordionProps>;
//#endregion
export { Accordion };
//# sourceMappingURL=Accordion.d.mts.map