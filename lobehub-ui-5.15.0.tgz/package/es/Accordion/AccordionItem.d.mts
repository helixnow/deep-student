import { AccordionItemProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Accordion/AccordionItem.d.ts
declare const AccordionItem: _$react.NamedExoticComponent<AccordionItemProps>;
//#endregion
export { AccordionItem };
//# sourceMappingURL=AccordionItem.d.mts.map