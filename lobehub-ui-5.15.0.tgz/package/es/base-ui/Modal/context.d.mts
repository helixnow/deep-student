import { ModalContextValue } from "./type.mjs";
import * as _$react from "react";

//#region src/base-ui/Modal/context.d.ts
declare const ModalContext: _$react.Context<ModalContextValue>;
declare const useModalContext: () => ModalContextValue;
//#endregion
export { ModalContext, useModalContext };
//# sourceMappingURL=context.d.mts.map