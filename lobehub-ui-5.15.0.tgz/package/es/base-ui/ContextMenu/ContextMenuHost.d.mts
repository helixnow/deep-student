import * as _$react from "react";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";

//#region src/base-ui/ContextMenu/ContextMenuHost.d.ts
declare const ContextMenuHost: _$react.MemoExoticComponent<() => _$react_jsx_runtime0.JSX.Element | null>;
//#endregion
export { ContextMenuHost };
//# sourceMappingURL=ContextMenuHost.d.mts.map