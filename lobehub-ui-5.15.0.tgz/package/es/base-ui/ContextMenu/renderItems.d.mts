import { IconAlign, IconSpaceMode } from "../../Menu/renderUtils.mjs";
import { ReactNode } from "react";