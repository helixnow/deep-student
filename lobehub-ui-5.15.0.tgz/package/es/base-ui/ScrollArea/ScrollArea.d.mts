import { ScrollAreaProps } from "./type.mjs";
import { FC } from "react";

//#region src/base-ui/ScrollArea/ScrollArea.d.ts
declare const ScrollArea: FC<ScrollAreaProps>;
//#endregion
export { ScrollArea };
//# sourceMappingURL=ScrollArea.d.mts.map