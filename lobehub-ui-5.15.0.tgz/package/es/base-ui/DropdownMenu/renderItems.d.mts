import { IconAlign, IconSpaceMode, RenderOptions } from "../../Menu/renderUtils.mjs";
import { DropdownItem } from "./type.mjs";
import { ReactNode } from "react";

//#region src/base-ui/DropdownMenu/renderItems.d.ts
declare const renderDropdownMenuItems: (items: DropdownItem[], keyPath?: string[], options?: RenderOptions) => ReactNode[];
//#endregion
export { renderDropdownMenuItems };
//# sourceMappingURL=renderItems.d.mts.map