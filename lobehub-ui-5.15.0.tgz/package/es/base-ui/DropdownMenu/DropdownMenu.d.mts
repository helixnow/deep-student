import { DropdownMenuProps } from "./type.mjs";
import * as _$react from "react";

//#region src/base-ui/DropdownMenu/DropdownMenu.d.ts
declare const DropdownMenu: _$react.NamedExoticComponent<DropdownMenuProps<unknown>>;
//#endregion
export { DropdownMenu };
//# sourceMappingURL=DropdownMenu.d.mts.map