import { PopoverPlacement } from "./type.mjs";
import * as _$react from "react";
import { ComponentProps, ComponentPropsWithRef } from "react";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";
import * as _$_base_ui_react_popover0 from "@base-ui/react/popover";
import { Popover } from "@base-ui/react/popover";

//#region src/base-ui/Popover/atoms.d.ts
declare const PopoverRoot: typeof Popover.Root;
declare const PopoverBackdrop: _$react.ForwardRefExoticComponent<_$_base_ui_react_popover0.PopoverBackdropProps & _$react.RefAttributes<HTMLDivElement>>;
type PopoverTriggerElementProps = Omit<ComponentPropsWithRef<typeof Popover.Trigger>, 'children' | 'render'> & {
  children: ComponentProps<typeof Popover.Trigger>['children'];
};
declare const PopoverTriggerElement: {
  ({
    children,
    className,
    nativeButton,
    ref: refProp,
    ...rest
  }: PopoverTriggerElementProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type PopoverPortalAtomProps = Omit<ComponentProps<typeof Popover.Portal>, 'container'> & {
  /**
   * Portal container. When not provided, it uses the shared container created by `usePopoverPortalContainer`.
   */
  container?: HTMLElement | null;
  /**
   * Root element used by `usePopoverPortalContainer` to create the default container.
   */
  root?: HTMLElement | ShadowRoot | null;
};
declare const PopoverPortal: {
  ({
    container,
    root,
    children,
    ...rest
  }: PopoverPortalAtomProps): _$react_jsx_runtime0.JSX.Element | null;
  displayName: string;
};
type PopoverPositionerAtomProps = ComponentProps<typeof Popover.Positioner> & {
  hoverTrigger?: boolean;
  placement?: PopoverPlacement;
};
declare const PopoverPositioner: {
  ({
    children,
    className,
    hoverTrigger,
    placement,
    align,
    side,
    sideOffset,
    style,
    ...rest
  }: PopoverPositionerAtomProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type PopoverPopupAtomProps = ComponentProps<typeof Popover.Popup>;
declare const PopoverPopup: {
  ({
    className,
    ...rest
  }: PopoverPopupAtomProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type PopoverArrowAtomProps = ComponentProps<typeof Popover.Arrow>;
declare const PopoverArrow: {
  ({
    className,
    children,
    ...rest
  }: PopoverArrowAtomProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type PopoverViewportAtomProps = ComponentProps<typeof Popover.Viewport>;
declare const PopoverViewport: {
  ({
    className,
    ...rest
  }: PopoverViewportAtomProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
//#endregion
export { PopoverArrow, PopoverArrowAtomProps, PopoverBackdrop, PopoverPopup, PopoverPopupAtomProps, PopoverPortal, PopoverPortalAtomProps, PopoverPositioner, PopoverPositionerAtomProps, PopoverRoot, PopoverTriggerElement, PopoverTriggerElementProps, PopoverViewport, PopoverViewportAtomProps };
//# sourceMappingURL=atoms.d.mts.map