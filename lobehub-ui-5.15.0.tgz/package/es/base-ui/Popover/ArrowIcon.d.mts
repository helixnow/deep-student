import * as _$react_jsx_runtime0 from "react/jsx-runtime";

//#region src/base-ui/Popover/ArrowIcon.d.ts
declare const PopoverArrowIcon: _$react_jsx_runtime0.JSX.Element;
//#endregion
export { PopoverArrowIcon };
//# sourceMappingURL=ArrowIcon.d.mts.map