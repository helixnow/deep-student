import { PopoverProps } from "./type.mjs";
import { parseTrigger } from "../../utils/parseTrigger.mjs";
import { FC } from "react";

//#region src/base-ui/Popover/Popover.d.ts
declare const Popover: FC<PopoverProps>;
//#endregion
export { Popover };
//# sourceMappingURL=Popover.d.mts.map