import { PopoverProps } from "./type.mjs";
import { Popover } from "@base-ui/react/popover";

//#region src/base-ui/Popover/groupContext.d.ts
type PopoverGroupSharedProps = Omit<PopoverProps, 'children' | 'content' | 'defaultOpen' | 'open' | 'ref'> & {
  /**
   * @description Whether to enable content layout animation when switching triggers
   * @default false
   */
  contentLayoutAnimation?: boolean;
  /**
   * Disable the "destroy on invalid trigger (display:none / disconnected)" guard for performance.
   * @default false
   */
  disableDestroyOnInvalidTrigger?: boolean;
  /**
   * Disable the "hide when positioner falls back to (0,0)" visual guard for performance.
   * @default false
   */
  disableZeroOriginGuard?: boolean;
};
//#endregion
export { PopoverGroupSharedProps };
//# sourceMappingURL=groupContext.d.mts.map