import * as _$react from "react";
import { ReactNode } from "react";

//#region src/base-ui/Popover/context.d.ts
type PopoverContextValue = {
  close: () => void;
};
declare const PopoverProvider: _$react.NamedExoticComponent<{
  children: ReactNode;
  value: PopoverContextValue;
}>;
declare const usePopoverContext: () => PopoverContextValue;
//#endregion
export { PopoverContextValue, PopoverProvider, usePopoverContext };
//# sourceMappingURL=context.d.mts.map