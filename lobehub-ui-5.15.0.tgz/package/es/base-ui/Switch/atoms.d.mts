import { SwitchChangeEventHandler, SwitchContextType, SwitchIconProps, SwitchRootProps, SwitchThumbProps } from "./type.mjs";
import { styles } from "./style.mjs";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";

//#region src/base-ui/Switch/atoms.d.ts
declare const useSwitchContext: () => SwitchContextType;
type SwitchRootInternalProps = Omit<SwitchRootProps, 'onCheckedChange' | 'onClick'> & {
  onCheckedChange?: SwitchChangeEventHandler;
  onClick?: SwitchChangeEventHandler;
};
declare const SwitchRoot: {
  ({
    checked,
    className,
    defaultChecked,
    onCheckedChange,
    onClick,
    size,
    children,
    disabled,
    readOnly,
    required,
    inputRef,
    id,
    name,
    ...rest
  }: SwitchRootInternalProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
declare const SwitchThumb: {
  ({
    className,
    pressedAnimation,
    size,
    transition,
    children,
    ...rest
  }: SwitchThumbProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
declare const SwitchIcon: {
  ({
    children,
    className,
    position,
    transition,
    ...rest
  }: SwitchIconProps & {
    children?: React.ReactNode;
    size?: "default" | "small";
  }): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
//#endregion
export { SwitchIcon, SwitchRoot, SwitchThumb, useSwitchContext };
//# sourceMappingURL=atoms.d.mts.map