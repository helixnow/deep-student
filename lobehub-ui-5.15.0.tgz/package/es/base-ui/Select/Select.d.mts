import { SelectProps } from "./type.mjs";
import * as _$react from "react";

//#region src/base-ui/Select/Select.d.ts
declare const Select: _$react.NamedExoticComponent<SelectProps<any>>;
//#endregion
export { Select };
//# sourceMappingURL=Select.d.mts.map