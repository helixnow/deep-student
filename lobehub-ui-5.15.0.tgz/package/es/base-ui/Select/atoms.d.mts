import { SeparatorProps } from "../../node_modules/@base-ui/react/esm/separator/Separator.mjs";
import { SelectSize, SelectVariant } from "./type.mjs";
import * as _$react from "react";
import { ComponentProps, ComponentPropsWithRef } from "react";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";
import * as _$_base_ui_react_select0 from "@base-ui/react/select";
import { Select } from "@base-ui/react/select";

//#region src/base-ui/Select/atoms.d.ts
declare const SelectRoot: typeof Select.Root;
declare const SelectBackdrop: _$react.ForwardRefExoticComponent<_$_base_ui_react_select0.SelectBackdropProps & _$react.RefAttributes<HTMLDivElement>>;
declare const SelectSeparator: _$react.ForwardRefExoticComponent<SeparatorProps & _$react.RefAttributes<HTMLDivElement>>;
type SelectTriggerProps = Omit<ComponentPropsWithRef<typeof Select.Trigger>, 'children' | 'render'> & {
  children: ComponentProps<typeof Select.Trigger>['children'];
  shadow?: boolean;
  size?: SelectSize;
  variant?: SelectVariant;
};
declare const SelectTrigger: {
  ({
    children,
    className,
    nativeButton,
    shadow,
    size,
    variant,
    ref: refProp,
    ...rest
  }: SelectTriggerProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectIconProps = ComponentProps<typeof Select.Icon>;
declare const SelectIcon: {
  ({
    className,
    ...rest
  }: SelectIconProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectValueProps = ComponentProps<typeof Select.Value>;
declare const SelectValue: {
  ({
    className,
    ...rest
  }: SelectValueProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectPortalProps = ComponentProps<typeof Select.Portal> & {
  /**
   * When `container` is not provided, it uses a shared container created by `usePortalContainer`.
   */
  container?: HTMLElement | null;
};
declare const SelectPortal: {
  ({
    container,
    ...rest
  }: SelectPortalProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectPositionerProps = ComponentProps<typeof Select.Positioner>;
declare const SelectPositioner: {
  ({
    align,
    alignItemWithTrigger,
    className,
    side,
    sideOffset,
    style,
    ref: forwardedRef,
    ...rest
  }: SelectPositionerProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectPopupProps = ComponentProps<typeof Select.Popup>;
declare const SelectPopup: {
  ({
    className,
    ...rest
  }: SelectPopupProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectListProps = ComponentProps<typeof Select.List>;
declare const SelectList: {
  ({
    className,
    ...rest
  }: SelectListProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectItemProps = ComponentProps<typeof Select.Item>;
declare const SelectItem: {
  ({
    className,
    ...rest
  }: SelectItemProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectItemTextProps = ComponentProps<typeof Select.ItemText>;
declare const SelectItemText: {
  ({
    className,
    ...rest
  }: SelectItemTextProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectItemIndicatorProps = ComponentProps<typeof Select.ItemIndicator>;
declare const SelectItemIndicator: {
  ({
    className,
    ...rest
  }: SelectItemIndicatorProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectGroupProps = ComponentProps<typeof Select.Group>;
declare const SelectGroup: {
  ({
    className,
    ...rest
  }: SelectGroupProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectGroupLabelProps = ComponentProps<typeof Select.GroupLabel>;
declare const SelectGroupLabel: {
  ({
    className,
    ...rest
  }: SelectGroupLabelProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectScrollUpArrowProps = ComponentProps<typeof Select.ScrollUpArrow>;
declare const SelectScrollUpArrow: {
  ({
    className,
    ...rest
  }: SelectScrollUpArrowProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectScrollDownArrowProps = ComponentProps<typeof Select.ScrollDownArrow>;
declare const SelectScrollDownArrow: {
  ({
    className,
    ...rest
  }: SelectScrollDownArrowProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type SelectArrowProps = ComponentProps<typeof Select.Arrow>;
declare const SelectArrow: {
  ({
    className,
    ...rest
  }: SelectArrowProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
//#endregion
export { SelectArrow, SelectArrowProps, SelectBackdrop, SelectGroup, SelectGroupLabel, SelectGroupLabelProps, SelectGroupProps, SelectIcon, SelectIconProps, SelectItem, SelectItemIndicator, SelectItemIndicatorProps, SelectItemProps, SelectItemText, SelectItemTextProps, SelectList, SelectListProps, SelectPopup, SelectPopupProps, SelectPortal, SelectPortalProps, SelectPositioner, SelectPositionerProps, SelectRoot, SelectScrollDownArrow, SelectScrollDownArrowProps, SelectScrollUpArrow, SelectScrollUpArrowProps, SelectSeparator, SelectTrigger, SelectTriggerProps, SelectValue, SelectValueProps };
//# sourceMappingURL=atoms.d.mts.map