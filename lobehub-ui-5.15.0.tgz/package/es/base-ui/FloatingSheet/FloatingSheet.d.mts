import { FloatingSheetProps } from "./type.mjs";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";

//#region src/base-ui/FloatingSheet/FloatingSheet.d.ts
declare function FloatingSheet({
  open: openProp,
  onOpenChange,
  defaultOpen,
  snapPoints: snapPointsProp,
  activeSnapPoint: activeSnapPointProp,
  onSnapPointChange,
  minHeight: minHeightProp,
  maxHeight: maxHeightProp,
  restingHeight: restingHeightProp,
  mode,
  variant,
  width,
  title,
  headerActions,
  dismissible,
  closeThreshold,
  children,
  className
}: FloatingSheetProps): _$react_jsx_runtime0.JSX.Element;
//#endregion
export { FloatingSheet };
//# sourceMappingURL=FloatingSheet.d.mts.map