import { CollapseProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Collapse/Collapse.d.ts
declare const Collapse: _$react.NamedExoticComponent<CollapseProps>;
//#endregion
export { Collapse };
//# sourceMappingURL=Collapse.d.mts.map