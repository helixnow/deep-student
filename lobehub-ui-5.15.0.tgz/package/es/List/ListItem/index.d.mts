import { ListItemProps } from "../type.mjs";
import * as _$react from "react";

//#region src/List/ListItem/index.d.ts
declare const ListItem: _$react.NamedExoticComponent<ListItemProps>;
//#endregion
export { ListItem };
//# sourceMappingURL=index.d.mts.map