import { DrawerProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Drawer/Drawer.d.ts
declare const Drawer: _$react.NamedExoticComponent<DrawerProps>;
//#endregion
export { Drawer };
//# sourceMappingURL=Drawer.d.mts.map