import { FormSubmitFooterProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Form/components/FormSubmitFooter.d.ts
declare const FormSubmitFooter: _$react.NamedExoticComponent<FormSubmitFooterProps>;
//#endregion
export { FormSubmitFooter };
//# sourceMappingURL=FormSubmitFooter.d.mts.map