import { FormItemProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Form/components/FormItem.d.ts
declare const FormItem: _$react.NamedExoticComponent<FormItemProps>;
//#endregion
export { FormItem };
//# sourceMappingURL=FormItem.d.mts.map