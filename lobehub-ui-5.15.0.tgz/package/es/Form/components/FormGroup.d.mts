import { FormGroupProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Form/components/FormGroup.d.ts
declare const FormGroup: _$react.NamedExoticComponent<FormGroupProps>;
//#endregion
export { FormGroup };
//# sourceMappingURL=FormGroup.d.mts.map