import { SearchBarProps } from "./type.mjs";
import * as _$react from "react";

//#region src/SearchBar/SearchBar.d.ts
declare const SearchBar: _$react.NamedExoticComponent<SearchBarProps>;
//#endregion
export { SearchBar };
//# sourceMappingURL=SearchBar.d.mts.map