import { IconProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Icon/Icon.d.ts
declare const Icon: _$react.NamedExoticComponent<IconProps>;
//#endregion
export { Icon };
//# sourceMappingURL=Icon.d.mts.map