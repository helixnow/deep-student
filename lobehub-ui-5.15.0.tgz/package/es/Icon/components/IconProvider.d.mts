import { IconProps } from "../type.mjs";
import * as _$react from "react";
import { ReactNode } from "react";

//#region src/Icon/components/IconProvider.d.ts
type IconContentConfig = Omit<IconProps, 'icon' | 'ref'>;
declare const IconContext: _$react.Context<IconContentConfig>;
declare const IconProvider: _$react.NamedExoticComponent<{
  children: ReactNode;
  config?: IconContentConfig;
}>;
declare const useIconContext: () => IconContentConfig;
//#endregion
export { IconContentConfig, IconContext, IconProvider, useIconContext };
//# sourceMappingURL=IconProvider.d.mts.map