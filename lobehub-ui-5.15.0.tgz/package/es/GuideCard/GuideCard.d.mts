import { GuideCardProps } from "./type.mjs";
import * as _$react from "react";

//#region src/GuideCard/GuideCard.d.ts
declare const GuideCard: _$react.NamedExoticComponent<GuideCardProps>;
//#endregion
export { GuideCard };
//# sourceMappingURL=GuideCard.d.mts.map