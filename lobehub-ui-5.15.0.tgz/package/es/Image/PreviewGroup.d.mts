import { PreviewGroupProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Image/PreviewGroup.d.ts
declare const PreviewGroup: _$react.NamedExoticComponent<PreviewGroupProps>;
//#endregion
export { PreviewGroup };
//# sourceMappingURL=PreviewGroup.d.mts.map