import { EmojiPickerProps } from "./type.mjs";
import * as _$react from "react";

//#region src/EmojiPicker/EmojiPicker.d.ts
declare const EmojiPicker: _$react.NamedExoticComponent<EmojiPickerProps>;
//#endregion
export { EmojiPicker };
//# sourceMappingURL=EmojiPicker.d.mts.map