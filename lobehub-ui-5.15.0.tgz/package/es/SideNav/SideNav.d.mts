import { SideNavProps } from "./type.mjs";
import * as _$react from "react";

//#region src/SideNav/SideNav.d.ts
declare const SideNav: _$react.NamedExoticComponent<SideNavProps>;
//#endregion
export { SideNav };
//# sourceMappingURL=SideNav.d.mts.map