import { FlexboxProps } from "../../../Flex/type.mjs";
import * as _$react from "react";
import { Ref } from "react";

//#region src/Markdown/components/SearchResultCards/index.d.ts
interface SearchResultItem {
  alt?: string;
  summary?: string;
  title?: string;
  url: string;
}
interface SearchResultCardsProps extends FlexboxProps {
  dataSource: string[] | SearchResultItem[];
  ref?: Ref<HTMLDivElement>;
}
declare const SearchResultCards: _$react.NamedExoticComponent<SearchResultCardsProps>;
//#endregion
export { SearchResultCards, SearchResultCardsProps };
//# sourceMappingURL=index.d.mts.map