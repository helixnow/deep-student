import { Root } from "../../node_modules/@types/hast/index.mjs";

//#region src/Markdown/plugins/rehypeStreamAnimated.d.ts
interface StreamAnimatedOptions {
  births?: number[];
  fadeDuration?: number;
  nowMs?: number;
  revealed?: boolean;
}
declare const rehypeStreamAnimated: (options?: StreamAnimatedOptions) => (tree: Root) => void;
//#endregion
export { rehypeStreamAnimated };
//# sourceMappingURL=rehypeStreamAnimated.d.mts.map