import { Node } from "../../node_modules/@types/unist/index.mjs";

//#region src/Markdown/plugins/rehypeKatexDir.d.ts
declare const rehypeKatexDir: () => (tree: Node) => void;
//#endregion
export { rehypeKatexDir };
//# sourceMappingURL=rehypeKatexDir.d.mts.map