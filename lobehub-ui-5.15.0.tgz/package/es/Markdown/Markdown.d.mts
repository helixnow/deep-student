import { MarkdownProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Markdown/Markdown.d.ts
declare const Markdown: _$react.NamedExoticComponent<MarkdownProps>;
//#endregion
export { Markdown };
//# sourceMappingURL=Markdown.d.mts.map