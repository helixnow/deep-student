import { SelectProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Select/Select.d.ts
/**
 * @deprecated Use `Select` from `@lobehub/ui/base-ui` instead.
 */
declare const Select: _$react.NamedExoticComponent<SelectProps>;
//#endregion
export { Select };
//# sourceMappingURL=Select.d.mts.map