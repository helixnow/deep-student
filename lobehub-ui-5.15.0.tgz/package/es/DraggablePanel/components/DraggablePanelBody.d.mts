import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/DraggablePanel/components/DraggablePanelBody.d.ts
type DraggablePanelBodyProps = DivProps;
declare const DraggablePanelBody: _$react.NamedExoticComponent<DivProps>;
//#endregion
export { DraggablePanelBody, DraggablePanelBodyProps };
//# sourceMappingURL=DraggablePanelBody.d.mts.map