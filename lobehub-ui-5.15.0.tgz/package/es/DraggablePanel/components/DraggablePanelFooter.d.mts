import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/DraggablePanel/components/DraggablePanelFooter.d.ts
type DraggablePanelFooterProps = DivProps;
declare const DraggablePanelFooter: _$react.NamedExoticComponent<DivProps>;
//#endregion
export { DraggablePanelFooter, DraggablePanelFooterProps };
//# sourceMappingURL=DraggablePanelFooter.d.mts.map