import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/DraggablePanel/components/DraggablePanelContainer.d.ts
type DraggablePanelContainerProps = DivProps;
declare const DraggablePanelContainer: _$react.NamedExoticComponent<DivProps>;
//#endregion
export { DraggablePanelContainer, DraggablePanelContainerProps };
//# sourceMappingURL=DraggablePanelContainer.d.mts.map