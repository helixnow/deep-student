import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/DraggablePanel/components/DraggablePanelHeader.d.ts
interface DraggablePanelHeaderProps extends Omit<DivProps, 'children'> {
  pin?: boolean;
  position?: 'left' | 'right';
  setExpand?: (expand: boolean) => void;
  setPin?: (pin: boolean) => void;
  title?: string;
}
declare const DraggablePanelHeader: _$react.NamedExoticComponent<DraggablePanelHeaderProps>;
//#endregion
export { DraggablePanelHeader, DraggablePanelHeaderProps };
//# sourceMappingURL=DraggablePanelHeader.d.mts.map