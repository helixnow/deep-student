import { LayoutHeaderProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutHeader.d.ts
declare const LayoutHeader: _$react.NamedExoticComponent<LayoutHeaderProps>;
//#endregion
export { LayoutHeader };
//# sourceMappingURL=LayoutHeader.d.mts.map