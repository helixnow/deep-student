import { LayoutSidebarInnerProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutSidebarInner.d.ts
declare const LayoutSidebarInner: _$react.NamedExoticComponent<LayoutSidebarInnerProps>;
//#endregion
export { LayoutSidebarInner };
//# sourceMappingURL=LayoutSidebarInner.d.mts.map