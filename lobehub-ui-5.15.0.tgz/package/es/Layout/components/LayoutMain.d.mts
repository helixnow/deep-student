import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutMain.d.ts
declare const LayoutMain: _$react.NamedExoticComponent<DivProps>;
//#endregion
export { LayoutMain };
//# sourceMappingURL=LayoutMain.d.mts.map