import { LayoutTocProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutToc.d.ts
declare const LayoutToc: _$react.NamedExoticComponent<LayoutTocProps>;
//#endregion
export { LayoutToc };
//# sourceMappingURL=LayoutToc.d.mts.map