import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutFooter.d.ts
declare const LayoutFooter: _$react.NamedExoticComponent<DivProps>;
//#endregion
export { LayoutFooter };
//# sourceMappingURL=LayoutFooter.d.mts.map