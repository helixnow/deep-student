import { LayoutSidebarProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Layout/components/LayoutSidebar.d.ts
declare const LayoutSidebar: _$react.NamedExoticComponent<LayoutSidebarProps>;
//#endregion
export { LayoutSidebar };
//# sourceMappingURL=LayoutSidebar.d.mts.map