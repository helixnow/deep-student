import React from "react";
import * as _$react_jsx_runtime0 from "react/jsx-runtime";
import * as _$_base_ui_react_autocomplete0 from "@base-ui/react/autocomplete";
import { Autocomplete } from "@base-ui/react/autocomplete";

//#region src/EditorSlashMenu/atoms.d.ts
declare const EditorSlashMenuRoot: typeof Autocomplete.Root;
declare const EditorSlashMenuList: {
  ({
    ref,
    className,
    ...rest
  }: React.ComponentProps<typeof Autocomplete.List> & {
    ref?: React.RefObject<HTMLDivElement | null>;
  }): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuPortalProps = React.ComponentProps<typeof Autocomplete.Portal> & {
  /**
   * When `container` is not provided, it uses a shared container created by `usePortalContainer`.
   */
  container?: HTMLElement | null;
};
declare const EditorSlashMenuPortal: {
  ({
    container,
    ...rest
  }: EditorSlashMenuPortalProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuPositionerProps = React.ComponentProps<typeof Autocomplete.Positioner>;
declare const EditorSlashMenuPositioner: {
  ({
    className,
    align,
    positionMethod,
    side,
    sideOffset,
    ...rest
  }: EditorSlashMenuPositionerProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuPopupProps = React.ComponentProps<typeof Autocomplete.Popup>;
declare const EditorSlashMenuPopup: {
  ({
    className,
    initialFocus,
    ...rest
  }: EditorSlashMenuPopupProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuItemProps = React.ComponentProps<typeof Autocomplete.Item> & {
  danger?: boolean;
};
declare const EditorSlashMenuItem: {
  ({
    className,
    danger,
    ...rest
  }: EditorSlashMenuItemProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
declare const EditorSlashMenuGroup: React.ForwardRefExoticComponent<_$_base_ui_react_autocomplete0.AutocompleteGroupProps & React.RefAttributes<HTMLDivElement>>;
type EditorSlashMenuGroupLabelProps = React.ComponentProps<typeof Autocomplete.GroupLabel>;
declare const EditorSlashMenuGroupLabel: {
  ({
    className,
    ...rest
  }: EditorSlashMenuGroupLabelProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuEmptyProps = React.ComponentProps<typeof Autocomplete.Empty>;
declare const EditorSlashMenuEmpty: {
  ({
    className,
    ...rest
  }: EditorSlashMenuEmptyProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuItemContentProps = React.HTMLAttributes<HTMLDivElement>;
declare const EditorSlashMenuItemContent: {
  ({
    className,
    ...rest
  }: EditorSlashMenuItemContentProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuItemIconProps = React.HTMLAttributes<HTMLSpanElement>;
declare const EditorSlashMenuItemIcon: {
  ({
    className,
    ...rest
  }: EditorSlashMenuItemIconProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuItemLabelProps = React.HTMLAttributes<HTMLSpanElement>;
declare const EditorSlashMenuItemLabel: {
  ({
    className,
    ...rest
  }: EditorSlashMenuItemLabelProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuItemExtraProps = React.HTMLAttributes<HTMLSpanElement>;
declare const EditorSlashMenuItemExtra: {
  ({
    className,
    ...rest
  }: EditorSlashMenuItemExtraProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
type EditorSlashMenuHiddenInputProps = React.ComponentProps<typeof Autocomplete.Input>;
declare const EditorSlashMenuHiddenInput: {
  ({
    className,
    ...rest
  }: EditorSlashMenuHiddenInputProps): _$react_jsx_runtime0.JSX.Element;
  displayName: string;
};
//#endregion
export { EditorSlashMenuEmpty, EditorSlashMenuGroup, EditorSlashMenuGroupLabel, EditorSlashMenuHiddenInput, EditorSlashMenuItem, EditorSlashMenuItemContent, EditorSlashMenuItemExtra, EditorSlashMenuItemIcon, EditorSlashMenuItemLabel, EditorSlashMenuList, EditorSlashMenuPopup, EditorSlashMenuPortal, EditorSlashMenuPositioner, EditorSlashMenuRoot };
//# sourceMappingURL=atoms.d.mts.map