import { FeaturesProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/Features/Features.d.ts
declare const Features: _$react.NamedExoticComponent<FeaturesProps>;
//#endregion
export { Features };
//# sourceMappingURL=Features.d.mts.map