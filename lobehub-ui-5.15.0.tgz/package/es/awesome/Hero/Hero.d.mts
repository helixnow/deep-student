import { HeroProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/Hero/Hero.d.ts
declare const Hero: _$react.NamedExoticComponent<HeroProps>;
//#endregion
export { Hero };
//# sourceMappingURL=Hero.d.mts.map