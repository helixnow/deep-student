import { ButtonProps } from "../../Button/type.mjs";
import * as _$react from "react";

//#region src/awesome/BottomGradientButton/BottomGradientButton.d.ts
declare const BottomGradientButton: _$react.NamedExoticComponent<ButtonProps>;
//#endregion
export { BottomGradientButton };
//# sourceMappingURL=BottomGradientButton.d.mts.map