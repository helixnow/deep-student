import { GradientButtonProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/GradientButton/GradientButton.d.ts
declare const GradientButton: _$react.NamedExoticComponent<GradientButtonProps>;
//#endregion
export { GradientButton };
//# sourceMappingURL=GradientButton.d.mts.map