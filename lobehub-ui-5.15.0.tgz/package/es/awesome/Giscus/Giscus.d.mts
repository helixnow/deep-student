import { GiscusProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/Giscus/Giscus.d.ts
declare const Giscus: _$react.NamedExoticComponent<GiscusProps>;
//#endregion
export { Giscus };
//# sourceMappingURL=Giscus.d.mts.map