import { GridBackgroundProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/GridBackground/GridBackground.d.ts
declare const GridBackground: _$react.NamedExoticComponent<GridBackgroundProps>;
//#endregion
export { GridBackground };
//# sourceMappingURL=GridBackground.d.mts.map