import { GridShowcaseProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/GridBackground/GridShowcase.d.ts
declare const GridShowcase: _$react.NamedExoticComponent<GridShowcaseProps>;
//#endregion
export { GridShowcase };
//# sourceMappingURL=GridShowcase.d.mts.map