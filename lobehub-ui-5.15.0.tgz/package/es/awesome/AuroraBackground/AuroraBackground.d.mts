import { AuroraBackgroundProps } from "./type.mjs";
import * as _$react from "react";

//#region src/awesome/AuroraBackground/AuroraBackground.d.ts
declare const AuroraBackground: _$react.NamedExoticComponent<AuroraBackgroundProps>;
//#endregion
export { AuroraBackground };
//# sourceMappingURL=AuroraBackground.d.mts.map