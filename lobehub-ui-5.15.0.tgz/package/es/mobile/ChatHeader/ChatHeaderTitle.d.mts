import { ChatHeaderTitleProps } from "./type.mjs";
import * as _$react from "react";

//#region src/mobile/ChatHeader/ChatHeaderTitle.d.ts
declare const ChatHeaderTitle: _$react.NamedExoticComponent<ChatHeaderTitleProps>;
//#endregion
export { ChatHeaderTitle };
//# sourceMappingURL=ChatHeaderTitle.d.mts.map