import { ChatSendButtonProps } from "../type.mjs";
import * as _$react from "react";

//#region src/mobile/ChatInputArea/components/ChatSendButton.d.ts
declare const ChatSendButton: _$react.NamedExoticComponent<ChatSendButtonProps>;
//#endregion
export { ChatSendButton };
//# sourceMappingURL=ChatSendButton.d.mts.map