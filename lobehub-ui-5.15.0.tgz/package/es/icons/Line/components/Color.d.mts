import { IconType } from "@lobehub/icons";

//#region src/icons/Line/components/Color.d.ts
declare const Icon: IconType;
//#endregion
export { Icon };
//# sourceMappingURL=Color.d.mts.map