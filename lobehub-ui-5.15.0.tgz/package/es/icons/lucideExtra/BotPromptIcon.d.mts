import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/BotPromptIcon.d.ts
declare const BotPromptIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { BotPromptIcon };
//# sourceMappingURL=BotPromptIcon.d.mts.map