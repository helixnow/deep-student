import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/RightDoubleClickIcon.d.ts
declare const RightDoubleClickIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { RightDoubleClickIcon };
//# sourceMappingURL=RightDoubleClickIcon.d.mts.map