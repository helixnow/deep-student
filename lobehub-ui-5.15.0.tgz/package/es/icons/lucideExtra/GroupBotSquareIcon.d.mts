import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/GroupBotSquareIcon.d.ts
declare const GroupBotSquareIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { GroupBotSquareIcon };
//# sourceMappingURL=GroupBotSquareIcon.d.mts.map