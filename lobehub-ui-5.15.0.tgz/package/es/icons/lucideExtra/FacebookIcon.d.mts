import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/FacebookIcon.d.ts
declare const FacebookIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { FacebookIcon };
//# sourceMappingURL=FacebookIcon.d.mts.map