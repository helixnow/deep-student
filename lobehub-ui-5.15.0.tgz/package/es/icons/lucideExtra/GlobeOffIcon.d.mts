import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/GlobeOffIcon.d.ts
declare const GlobeOffIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { GlobeOffIcon };
//# sourceMappingURL=GlobeOffIcon.d.mts.map