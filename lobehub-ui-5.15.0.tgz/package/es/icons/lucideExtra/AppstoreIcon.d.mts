import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/AppstoreIcon.d.ts
declare const AppstoreIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { AppstoreIcon };
//# sourceMappingURL=AppstoreIcon.d.mts.map