import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/CodesandboxIcon.d.ts
declare const CodesandboxIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { CodesandboxIcon };
//# sourceMappingURL=CodesandboxIcon.d.mts.map