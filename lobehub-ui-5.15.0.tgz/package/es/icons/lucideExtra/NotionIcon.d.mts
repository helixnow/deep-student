import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/NotionIcon.d.ts
declare const NotionIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { NotionIcon };
//# sourceMappingURL=NotionIcon.d.mts.map