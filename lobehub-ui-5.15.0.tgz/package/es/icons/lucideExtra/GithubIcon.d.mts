import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/GithubIcon.d.ts
declare const GithubIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { GithubIcon };
//# sourceMappingURL=GithubIcon.d.mts.map