import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/AndroidIcon.d.ts
declare const AndroidIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { AndroidIcon };
//# sourceMappingURL=AndroidIcon.d.mts.map