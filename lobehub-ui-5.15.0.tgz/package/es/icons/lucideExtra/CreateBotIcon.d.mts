import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/CreateBotIcon.d.ts
declare const CreateBotIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { CreateBotIcon };
//# sourceMappingURL=CreateBotIcon.d.mts.map