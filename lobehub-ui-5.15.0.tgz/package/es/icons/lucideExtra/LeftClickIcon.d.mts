import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/LeftClickIcon.d.ts
declare const LeftClickIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { LeftClickIcon };
//# sourceMappingURL=LeftClickIcon.d.mts.map