import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/LeftDoubleClickIcon.d.ts
declare const LeftDoubleClickIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { LeftDoubleClickIcon };
//# sourceMappingURL=LeftDoubleClickIcon.d.mts.map