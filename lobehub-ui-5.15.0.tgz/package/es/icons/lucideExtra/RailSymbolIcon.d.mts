import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/RailSymbolIcon.d.ts
declare const RailSymbolIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { RailSymbolIcon };
//# sourceMappingURL=RailSymbolIcon.d.mts.map