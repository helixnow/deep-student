import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/SkillsIcon.d.ts
declare const SkillsIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { SkillsIcon };
//# sourceMappingURL=SkillsIcon.d.mts.map