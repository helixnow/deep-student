import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/ProviderIcon.d.ts
declare const ProviderIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { ProviderIcon };
//# sourceMappingURL=ProviderIcon.d.mts.map