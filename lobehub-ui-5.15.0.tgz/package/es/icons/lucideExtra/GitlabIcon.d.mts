import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/GitlabIcon.d.ts
declare const GitlabIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { GitlabIcon };
//# sourceMappingURL=GitlabIcon.d.mts.map