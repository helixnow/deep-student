import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/BrainOffIcon.d.ts
declare const BrainOffIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { BrainOffIcon };
//# sourceMappingURL=BrainOffIcon.d.mts.map