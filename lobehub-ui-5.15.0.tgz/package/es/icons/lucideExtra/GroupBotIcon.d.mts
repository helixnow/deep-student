import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/GroupBotIcon.d.ts
declare const GroupBotIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { GroupBotIcon };
//# sourceMappingURL=GroupBotIcon.d.mts.map