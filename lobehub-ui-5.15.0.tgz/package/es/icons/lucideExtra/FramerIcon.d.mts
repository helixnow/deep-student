import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/FramerIcon.d.ts
declare const FramerIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { FramerIcon };
//# sourceMappingURL=FramerIcon.d.mts.map