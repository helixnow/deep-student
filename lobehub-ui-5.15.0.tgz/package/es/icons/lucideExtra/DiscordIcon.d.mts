import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/DiscordIcon.d.ts
declare const DiscordIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { DiscordIcon };
//# sourceMappingURL=DiscordIcon.d.mts.map