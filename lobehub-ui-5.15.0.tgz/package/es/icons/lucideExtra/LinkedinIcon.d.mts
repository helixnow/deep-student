import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/LinkedinIcon.d.ts
declare const LinkedinIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { LinkedinIcon };
//# sourceMappingURL=LinkedinIcon.d.mts.map