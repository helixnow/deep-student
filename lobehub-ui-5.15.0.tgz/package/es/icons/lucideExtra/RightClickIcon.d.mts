import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/RightClickIcon.d.ts
declare const RightClickIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { RightClickIcon };
//# sourceMappingURL=RightClickIcon.d.mts.map