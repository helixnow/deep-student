import * as _$react from "react";
import * as _$lucide_react0 from "lucide-react";

//#region src/icons/lucideExtra/CodepenIcon.d.ts
declare const CodepenIcon: _$react.ForwardRefExoticComponent<Omit<_$lucide_react0.LucideProps, "ref"> & _$react.RefAttributes<SVGSVGElement>>;
//#endregion
export { CodepenIcon };
//# sourceMappingURL=CodepenIcon.d.mts.map