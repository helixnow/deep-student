import { IconType } from "@lobehub/icons";

//#region src/icons/Lark/components/Mono.d.ts
declare const Icon: IconType;
//#endregion
export { Icon };
//# sourceMappingURL=Mono.d.mts.map