import { FC } from "react";
import { IconAvatarProps } from "@lobehub/icons";

//#region src/icons/Lark/components/Avatar.d.ts
type AvatarProps = Omit<IconAvatarProps, 'Icon'>;
declare const Avatar: FC<AvatarProps>;
//#endregion
export { Avatar };
//# sourceMappingURL=Avatar.d.mts.map