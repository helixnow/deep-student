import { AlertProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Alert/Alert.d.ts
declare const Alert: _$react.NamedExoticComponent<AlertProps>;
//#endregion
export { Alert };
//# sourceMappingURL=Alert.d.mts.map