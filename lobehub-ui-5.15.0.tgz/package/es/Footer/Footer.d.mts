import { FooterProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Footer/Footer.d.ts
declare const Footer: _$react.NamedExoticComponent<FooterProps>;
//#endregion
export { Footer };
//# sourceMappingURL=Footer.d.mts.map