import { ActionIconProps } from "../../ActionIcon/type.mjs";
import * as _$react from "react";

//#region src/SortableList/components/DragHandle.d.ts
declare const DragHandle: _$react.NamedExoticComponent<ActionIconProps>;
//#endregion
export { DragHandle };
//# sourceMappingURL=DragHandle.d.mts.map