import { FlexboxProps } from "../../Flex/type.mjs";
import * as _$react from "react";
import { Ref } from "react";
import { useControls, useCreateStore } from "leva";

//#region src/storybook/StoryBook/index.d.ts
interface StoryBookProps extends FlexboxProps {
  levaStore: any;
  noPadding?: boolean;
  ref?: Ref<HTMLDivElement>;
}
declare const StoryBook: _$react.NamedExoticComponent<StoryBookProps>;
//#endregion
export { StoryBook, StoryBookProps, useControls, useCreateStore };
//# sourceMappingURL=index.d.mts.map