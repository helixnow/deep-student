import { BurgerProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Burger/Burger.d.ts
declare const Burger: _$react.NamedExoticComponent<BurgerProps>;
//#endregion
export { Burger };
//# sourceMappingURL=Burger.d.mts.map