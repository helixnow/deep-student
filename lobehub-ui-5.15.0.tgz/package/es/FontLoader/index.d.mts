import * as _$react from "react";

//#region src/FontLoader/index.d.ts
interface FontLoaderProps {
  url: string;
}
declare const FontLoader: _$react.NamedExoticComponent<FontLoaderProps>;
//#endregion
export { FontLoader, FontLoaderProps };
//# sourceMappingURL=index.d.mts.map