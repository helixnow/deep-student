import { ActionIconProps } from "./type.mjs";
import * as _$react from "react";

//#region src/ActionIcon/ActionIcon.d.ts
declare const ActionIcon: _$react.NamedExoticComponent<ActionIconProps>;
//#endregion
export { ActionIcon };
//# sourceMappingURL=ActionIcon.d.mts.map