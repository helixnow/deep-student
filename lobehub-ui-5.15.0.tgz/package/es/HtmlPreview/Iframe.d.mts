import { HtmlPreviewIframeProps } from "./type.mjs";
import * as _$react from "react";

//#region src/HtmlPreview/Iframe.d.ts
declare const HtmlPreviewIframe: _$react.NamedExoticComponent<HtmlPreviewIframeProps>;
//#endregion
export { HtmlPreviewIframe };
//# sourceMappingURL=Iframe.d.mts.map