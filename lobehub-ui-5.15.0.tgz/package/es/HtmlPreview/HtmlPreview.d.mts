import { HtmlPreviewProps } from "./type.mjs";
import * as _$react from "react";

//#region src/HtmlPreview/HtmlPreview.d.ts
declare const HtmlPreview: _$react.NamedExoticComponent<HtmlPreviewProps>;
//#endregion
export { HtmlPreview };
//# sourceMappingURL=HtmlPreview.d.mts.map