import { I18nContextValue, TranslationKey, TranslationResources, TranslationResourcesInput } from "./types.mjs";
import { MotionComponentType } from "../MotionProvider/index.mjs";
import * as _$react from "react";
import { ReactNode } from "react";

//#region src/i18n/context.d.ts
interface I18nProviderProps {
  children: ReactNode;
  locale?: string;
  motion: MotionComponentType;
  resources?: TranslationResourcesInput;
}
declare const I18nProvider: _$react.NamedExoticComponent<I18nProviderProps>;
//#endregion
export { I18nProvider, I18nProviderProps };
//# sourceMappingURL=context.d.mts.map