import { EditableTextProps } from "./type.mjs";
import * as _$react from "react";

//#region src/EditableText/EditableText.d.ts
declare const EditableText: _$react.NamedExoticComponent<EditableTextProps>;
//#endregion
export { EditableText };
//# sourceMappingURL=EditableText.d.mts.map