import { ActionIconProps } from "../ActionIcon/type.mjs";
import { InputProps } from "../Input/type.mjs";
//#region src/EditableText/ControlInput.d.ts
interface ControlInputProps extends Omit<InputProps, 'onChange' | 'value' | 'onAbort'> {
  onChange?: (value: string) => void;
  onChangeEnd?: (value: string) => void;
  onValueChanging?: (value: string) => void;
  submitIcon?: ActionIconProps['icon'];
  texts?: {
    reset?: string;
    submit?: string;
  };
  value?: string;
}
//#endregion
export { ControlInputProps };
//# sourceMappingURL=ControlInput.d.mts.map