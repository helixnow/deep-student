import { InputNumberProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Input/InputNumber.d.ts
declare const InputNumber: _$react.NamedExoticComponent<InputNumberProps>;
//#endregion
export { InputNumber };
//# sourceMappingURL=InputNumber.d.mts.map