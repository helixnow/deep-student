import { InputProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Input/Input.d.ts
declare const Input: _$react.NamedExoticComponent<InputProps>;
//#endregion
export { Input };
//# sourceMappingURL=Input.d.mts.map