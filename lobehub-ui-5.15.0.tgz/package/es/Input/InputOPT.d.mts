import { InputOPTProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Input/InputOPT.d.ts
declare const InputOPT: _$react.NamedExoticComponent<InputOPTProps>;
//#endregion
export { InputOPT };
//# sourceMappingURL=InputOPT.d.mts.map