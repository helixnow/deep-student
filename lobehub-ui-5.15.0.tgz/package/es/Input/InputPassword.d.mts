import { InputPasswordProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Input/InputPassword.d.ts
declare const InputPassword: _$react.NamedExoticComponent<InputPasswordProps>;
//#endregion
export { InputPassword };
//# sourceMappingURL=InputPassword.d.mts.map