import { CopyButtonProps } from "./type.mjs";
import * as _$react from "react";

//#region src/CopyButton/CopyButton.d.ts
declare const CopyButton: _$react.NamedExoticComponent<CopyButtonProps>;
//#endregion
export { CopyButton };
//# sourceMappingURL=CopyButton.d.mts.map