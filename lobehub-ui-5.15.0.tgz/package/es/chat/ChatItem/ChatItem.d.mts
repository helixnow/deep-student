import { ChatItemProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/ChatItem/ChatItem.d.ts
declare const ChatItem: _$react.NamedExoticComponent<ChatItemProps>;
//#endregion
export { ChatItem };
//# sourceMappingURL=ChatItem.d.mts.map