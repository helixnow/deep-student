import { EditableMessageListProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/EditableMessageList/EditableMessageList.d.ts
declare const EditableMessageList: _$react.NamedExoticComponent<EditableMessageListProps>;
//#endregion
export { EditableMessageList };
//# sourceMappingURL=EditableMessageList.d.mts.map