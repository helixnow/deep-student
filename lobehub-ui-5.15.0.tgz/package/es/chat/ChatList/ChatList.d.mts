import { ChatListProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/ChatList/ChatList.d.ts
declare const ChatList: _$react.NamedExoticComponent<ChatListProps>;
//#endregion
export { ChatList };
//# sourceMappingURL=ChatList.d.mts.map