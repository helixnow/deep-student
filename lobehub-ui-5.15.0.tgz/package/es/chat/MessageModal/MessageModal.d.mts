import { MessageModalProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/MessageModal/MessageModal.d.ts
declare const MessageModal: _$react.NamedExoticComponent<MessageModalProps>;
//#endregion
export { MessageModal };
//# sourceMappingURL=MessageModal.d.mts.map