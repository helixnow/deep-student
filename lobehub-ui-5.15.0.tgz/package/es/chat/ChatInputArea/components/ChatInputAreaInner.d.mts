import { ChatInputAreaInnerProps } from "../type.mjs";
import * as _$react from "react";

//#region src/chat/ChatInputArea/components/ChatInputAreaInner.d.ts
declare const ChatInputAreaInner: _$react.NamedExoticComponent<ChatInputAreaInnerProps>;
//#endregion
export { ChatInputAreaInner };
//# sourceMappingURL=ChatInputAreaInner.d.mts.map