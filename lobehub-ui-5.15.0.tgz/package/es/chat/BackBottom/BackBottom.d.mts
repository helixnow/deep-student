import { BackBottomProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/BackBottom/BackBottom.d.ts
declare const BackBottom: _$react.NamedExoticComponent<BackBottomProps>;
//#endregion
export { BackBottom };
//# sourceMappingURL=BackBottom.d.mts.map