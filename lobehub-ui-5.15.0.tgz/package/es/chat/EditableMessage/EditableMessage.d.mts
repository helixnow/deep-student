import { EditableMessageProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/EditableMessage/EditableMessage.d.ts
declare const EditableMessage: _$react.NamedExoticComponent<EditableMessageProps>;
//#endregion
export { EditableMessage };
//# sourceMappingURL=EditableMessage.d.mts.map