import { MessageInputProps } from "./type.mjs";
import * as _$react from "react";

//#region src/chat/MessageInput/MessageInput.d.ts
declare const MessageInput: _$react.NamedExoticComponent<MessageInputProps>;
//#endregion
export { MessageInput };
//# sourceMappingURL=MessageInput.d.mts.map