import { MaskShadowProps } from "./type.mjs";
import * as _$react from "react";

//#region src/MaskShadow/MaskShadow.d.ts
declare const MaskShadow: _$react.NamedExoticComponent<MaskShadowProps>;
//#endregion
export { MaskShadow };
//# sourceMappingURL=MaskShadow.d.mts.map