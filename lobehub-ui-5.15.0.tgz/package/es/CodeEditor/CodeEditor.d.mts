import { CodeEditorProps } from "./type.mjs";
import * as _$react from "react";

//#region src/CodeEditor/CodeEditor.d.ts
declare const CodeEditor: _$react.NamedExoticComponent<CodeEditorProps>;
//#endregion
export { CodeEditor };
//# sourceMappingURL=CodeEditor.d.mts.map