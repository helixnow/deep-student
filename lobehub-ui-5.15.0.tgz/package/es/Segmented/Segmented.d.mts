import { SegmentedProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Segmented/Segmented.d.ts
declare const Segmented: _$react.NamedExoticComponent<SegmentedProps>;
//#endregion
export { Segmented };
//# sourceMappingURL=Segmented.d.mts.map