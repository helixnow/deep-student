import { DropdownProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Dropdown/Dropdown.d.ts
/**
 * @deprecated
 * Use `DropdownMenu` or `ContextMenu` instead
 * @see https://ui.lobehub.com/components/context-menu
 * @see https://ui.lobehub.com/components/dropdown-menu
 */
declare const Dropdown: _$react.NamedExoticComponent<DropdownProps>;
//#endregion
export { Dropdown };
//# sourceMappingURL=Dropdown.d.mts.map