import { HotkeyProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Hotkey/Hotkey.d.ts
declare const Hotkey: _$react.NamedExoticComponent<HotkeyProps>;
//#endregion
export { Hotkey };
//# sourceMappingURL=Hotkey.d.mts.map