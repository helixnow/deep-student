import { AutoCompleteProps } from "./type.mjs";
import * as _$react from "react";

//#region src/AutoComplete/Select.d.ts
declare const AutoComplete: _$react.NamedExoticComponent<AutoCompleteProps>;
//#endregion
export { AutoComplete };
//# sourceMappingURL=Select.d.mts.map