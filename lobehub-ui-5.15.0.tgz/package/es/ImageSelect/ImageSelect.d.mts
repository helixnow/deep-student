import { ImageSelectProps } from "./type.mjs";
import * as _$react from "react";

//#region src/ImageSelect/ImageSelect.d.ts
declare const ImageSelect: _$react.NamedExoticComponent<ImageSelectProps>;
//#endregion
export { ImageSelect };
//# sourceMappingURL=ImageSelect.d.mts.map