import { PatchDiffProps } from "./type.mjs";
import * as _$react from "react";

//#region src/CodeDiff/PatchDiff.d.ts
declare const PatchDiff: _$react.NamedExoticComponent<PatchDiffProps>;
//#endregion
export { PatchDiff };
//# sourceMappingURL=PatchDiff.d.mts.map