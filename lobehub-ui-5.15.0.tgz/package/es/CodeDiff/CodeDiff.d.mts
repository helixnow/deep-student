import { CodeDiffProps } from "./type.mjs";
import * as _$react from "react";

//#region src/CodeDiff/CodeDiff.d.ts
declare const CodeDiff: _$react.NamedExoticComponent<CodeDiffProps>;
//#endregion
export { CodeDiff };
//# sourceMappingURL=CodeDiff.d.mts.map