import { HeaderProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Header/Header.d.ts
declare const Header: _$react.NamedExoticComponent<HeaderProps>;
//#endregion
export { Header };
//# sourceMappingURL=Header.d.mts.map