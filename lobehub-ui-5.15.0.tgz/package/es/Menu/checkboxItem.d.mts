import { IconProps } from "../Icon/type.mjs";
import { Key, ReactNode } from "react";

//#region src/Menu/checkboxItem.d.ts
/**
 * Checkbox menu item shared by DropdownMenu / ContextMenu.
 * This is intentionally aligned with Base UI's `Menu.CheckboxItem` API we use.
 */
interface MenuCheckboxItemType {
  checked?: boolean;
  closeOnClick?: boolean;
  danger?: boolean;
  defaultChecked?: boolean;
  desc?: ReactNode;
  disabled?: boolean;
  extra?: ReactNode;
  icon?: IconProps['icon'];
  key: Key;
  label?: ReactNode;
  onCheckedChange?: (checked: boolean) => void;
  title?: ReactNode;
  type: 'checkbox';
}
//#endregion
export { MenuCheckboxItemType };
//# sourceMappingURL=checkboxItem.d.mts.map