import { MenuProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Menu/Menu.d.ts
declare const Menu: _$react.NamedExoticComponent<MenuProps<unknown>>;
//#endregion
export { Menu };
//# sourceMappingURL=Menu.d.mts.map