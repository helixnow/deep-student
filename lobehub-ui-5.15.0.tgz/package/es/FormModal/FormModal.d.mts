import { FormModalProps } from "./type.mjs";
import * as _$react from "react";

//#region src/FormModal/FormModal.d.ts
declare const FormModal: _$react.NamedExoticComponent<FormModalProps>;
//#endregion
export { FormModal };
//# sourceMappingURL=FormModal.d.mts.map