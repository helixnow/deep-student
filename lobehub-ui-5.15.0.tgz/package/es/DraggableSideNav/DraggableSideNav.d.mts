import { DraggableSideNavProps } from "./type.mjs";
import * as _$react from "react";

//#region src/DraggableSideNav/DraggableSideNav.d.ts
declare const DraggableSideNav: _$react.NamedExoticComponent<DraggableSideNavProps>;
//#endregion
export { DraggableSideNav };
//# sourceMappingURL=DraggableSideNav.d.mts.map