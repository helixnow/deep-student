import { HighlighterProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Highlighter/Highlighter.d.ts
declare const Highlighter: _$react.NamedExoticComponent<HighlighterProps>;
//#endregion
export { Highlighter };
//# sourceMappingURL=Highlighter.d.mts.map