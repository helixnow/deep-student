import { SyntaxHighlighterProps } from "../type.mjs";
import * as _$react from "react";

//#region src/Highlighter/SyntaxHighlighter/index.d.ts
declare const SyntaxHighlighter: _$react.NamedExoticComponent<SyntaxHighlighterProps>;
//#endregion
export { SyntaxHighlighter };
//# sourceMappingURL=index.d.mts.map