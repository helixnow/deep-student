import { MDXComponents } from "../../node_modules/@types/mdx/types.mjs";

//#region src/mdx/mdxComponents/index.d.ts
declare const mdxComponents: MDXComponents;
//#endregion
export { mdxComponents };
//# sourceMappingURL=index.d.mts.map