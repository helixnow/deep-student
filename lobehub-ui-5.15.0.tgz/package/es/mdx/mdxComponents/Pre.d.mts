import { HighlighterProps } from "../../Highlighter/type.mjs";
import { SnippetProps } from "../../Snippet/type.mjs";
import { FC } from "react";

//#region src/mdx/mdxComponents/Pre.d.ts
type PreProps = HighlighterProps;
declare const Pre: FC<PreProps>;
declare const PreSingleLine: FC<SnippetProps>;
//#endregion
export { Pre, PreProps, PreSingleLine };
//# sourceMappingURL=Pre.d.mts.map