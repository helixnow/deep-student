import { GridProps } from "../../Grid/type.mjs";
import { FC } from "react";

//#region src/mdx/Cards/index.d.ts
type CardsProps = GridProps;
declare const Cards: FC<CardsProps>;
//#endregion
export { Cards, CardsProps };
//# sourceMappingURL=index.d.mts.map