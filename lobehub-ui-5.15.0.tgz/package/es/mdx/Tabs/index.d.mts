import { FlexboxProps } from "../../Flex/type.mjs";
import { TabsProps as TabsProps$1 } from "../../Tabs/type.mjs";
import { FC, ReactNode } from "react";

//#region src/mdx/Tabs/index.d.ts
interface TabsProps extends Omit<FlexboxProps, 'children'> {
  children: ReactNode[];
  defaultIndex?: number | string;
  items: string[];
  tabNavProps?: Partial<TabsProps$1>;
}
declare const Tabs: FC<TabsProps>;
//#endregion
export { Tabs, TabsProps };
//# sourceMappingURL=index.d.mts.map