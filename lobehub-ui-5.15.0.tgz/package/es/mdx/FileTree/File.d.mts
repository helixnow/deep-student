import { FlexboxProps } from "../../Flex/type.mjs";
import { IconProps } from "../../Icon/type.mjs";
import { FC } from "react";

//#region src/mdx/FileTree/File.d.ts
interface FileProps extends Omit<FlexboxProps, 'children'> {
  icon?: IconProps['icon'];
  name: string;
}
declare const File: FC<FileProps>;
//#endregion
export { File, FileProps };
//# sourceMappingURL=File.d.mts.map