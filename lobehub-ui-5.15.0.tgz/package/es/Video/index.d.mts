import { FlexboxProps } from "../Flex/type.mjs";
import { VideoProps as VideoProps$1 } from "../types/index.mjs";
import * as _$react from "react";
import { CSSProperties, Ref } from "react";

//#region src/Video/index.d.ts
interface VideoProps extends VideoProps$1, Pick<FlexboxProps, 'width' | 'height'> {
  autoPlay?: boolean;
  classNames?: {
    mask?: string;
    video?: string;
    wrapper?: string;
  };
  isLoading?: boolean;
  loop?: boolean;
  maxHeight?: number | string;
  maxWidth?: number | string;
  minHeight?: number | string;
  minWidth?: number | string;
  muted?: HTMLVideoElement['muted'];
  onEnded?: VideoProps$1['onEnded'];
  onMouseEnter?: VideoProps$1['onMouseEnter'];
  onMouseLeave?: VideoProps$1['onMouseLeave'];
  onPause?: VideoProps$1['onPause'];
  onPlay?: VideoProps$1['onPlay'];
  onPlaying?: VideoProps$1['onPlaying'];
  onProgress?: VideoProps$1['onProgress'];
  poster?: string;
  preload?: HTMLVideoElement['preload'];
  preview?: boolean;
  ref?: Ref<HTMLDivElement>;
  size?: number | string;
  src: string;
  styles?: {
    mask?: CSSProperties;
    video?: CSSProperties;
    wrapper?: CSSProperties;
  };
  variant?: 'borderless' | 'filled' | 'outlined';
}
declare const Video: _$react.NamedExoticComponent<VideoProps>;
//#endregion
export { Video, VideoProps };
//# sourceMappingURL=index.d.mts.map