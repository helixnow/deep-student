import { DivProps } from "../../types/index.mjs";
import * as _$react from "react";
import { ReactNode } from "react";

//#region src/brand/LobeChat/index.d.ts
interface LobeChatProps extends DivProps {
  extra?: ReactNode;
  size?: number;
  type?: '3d' | 'flat' | 'mono' | 'text' | 'combine';
}
declare const LobeChat: _$react.NamedExoticComponent<LobeChatProps>;
//#endregion
export { LobeChat, LobeChatProps };
//# sourceMappingURL=index.d.mts.map