import { SplineProps } from "../../awesome/Spline/type.mjs";
import * as _$react from "react";
import { CSSProperties } from "react";

//#region src/brand/LogoThree/LogoSpline.d.ts
interface LogoSplineProps extends Partial<SplineProps> {
  className?: string;
  height?: number | string;
  style?: CSSProperties;
  width?: number | string;
}
declare const LogoSpline: _$react.NamedExoticComponent<LogoSplineProps>;
//#endregion
export { LogoSpline, LogoSplineProps };
//# sourceMappingURL=LogoSpline.d.mts.map