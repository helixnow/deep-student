import { SplineProps } from "../../awesome/Spline/type.mjs";
import * as _$react from "react";
import { CSSProperties } from "react";

//#region src/brand/LogoThree/index.d.ts
interface LogoThreeProps extends Partial<SplineProps> {
  className?: string;
  size?: number;
  style?: CSSProperties;
}
declare const LogoThree: _$react.NamedExoticComponent<LogoThreeProps>;
//#endregion
export { LogoThree, LogoThreeProps };
//# sourceMappingURL=index.d.mts.map