import { SliderWithInputProps } from "./type.mjs";
import * as _$react from "react";

//#region src/SliderWithInput/SliderWithInput.d.ts
declare const SliderWithInput: _$react.NamedExoticComponent<SliderWithInputProps>;
//#endregion
export { SliderWithInput };
//# sourceMappingURL=SliderWithInput.d.mts.map