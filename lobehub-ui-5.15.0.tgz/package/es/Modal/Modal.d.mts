import { ModalProps } from "./type.mjs";
import * as _$react from "react";

//#region src/Modal/Modal.d.ts
declare const Modal: _$react.NamedExoticComponent<ModalProps>;
//#endregion
export { Modal };
//# sourceMappingURL=Modal.d.mts.map