import { ModalContextValue } from "./type.mjs";
import * as _$react from "react";
import { ReactNode } from "react";

//#region src/Modal/ModalProvider.d.ts
declare const ModalProvider: _$react.NamedExoticComponent<{
  children: ReactNode;
  value: ModalContextValue;
}>;
declare const useModalContext: () => ModalContextValue;
//#endregion
export { ModalProvider, useModalContext };
//# sourceMappingURL=ModalProvider.d.mts.map